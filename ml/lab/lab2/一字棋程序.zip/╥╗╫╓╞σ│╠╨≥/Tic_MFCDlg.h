// Tic_MFCDlg.h : header file
//

#if !defined(AFX_TIC_MFCDLG_H__597AEB91_E1F4_4D8A_8D3B_31161877EB42__INCLUDED_)
#define AFX_TIC_MFCDLG_H__597AEB91_E1F4_4D8A_8D3B_31161877EB42__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTic_MFCDlg dialog

class CTic_MFCDlg : public CDialog
{
// Construction
public:
	int SearchDepth;
	int AlphaBeta(int Board[], int Depth , int turn, int Alpha ,int Beta,int* result);
	int evaluate(int board[]);
	static const CRect m_chessSquares[9];
	static int winPattern[8][3];
	void PutAChess( CDC *pDC,int Pos );
	int isWin( int curPos );
	int turn;
	void Reset();
	int Chess[9];
	void DrawBoard (CDC *pDC );
	void DrawO (CDC* pDC, int Pos);
	void DrawX (CDC* pDC, int Pos);
	CTic_MFCDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTic_MFCDlg)
	enum { IDD = IDD_TIC_MFC_DIALOG };
	int		m_dept;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTic_MFCDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTic_MFCDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnStartCom();
	afx_msg void OnStartPly();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIC_MFCDLG_H__597AEB91_E1F4_4D8A_8D3B_31161877EB42__INCLUDED_)
